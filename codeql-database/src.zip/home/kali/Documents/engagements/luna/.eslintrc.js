module.exports = {
  extends: ['eslint:recommended', 'plugin:security/recommended'],
  plugins: ['security'],
  parserOptions: {
    ecmaVersion: 2018,
    sourceType: 'module',
  },
  env: {
    browser: true,
    node: true,
  },
  rules: {
    'security/detect-object-injection': 'error',
    'security/detect-unsafe-regex': 'error',
    'security/detect-non-literal-fs-filename': 'error',
    'security/detect-non-literal-regexp': 'error',
    'security/detect-non-literal-require': 'error',
    'security/detect-eval-with-expression': 'error',
    'security/detect-child-process': 'error',
    'security/detect-buffer-noassert': 'error',
  },
};
